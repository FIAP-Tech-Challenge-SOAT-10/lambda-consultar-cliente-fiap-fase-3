INSERT INTO cliente (cpf, nome, email, telefone) VALUES
('12345678901', 'Test User 1', 'test1@example.com', '11999999999'),
('98765432101', 'Test User 2', 'test2@example.com', '11988888888'); 